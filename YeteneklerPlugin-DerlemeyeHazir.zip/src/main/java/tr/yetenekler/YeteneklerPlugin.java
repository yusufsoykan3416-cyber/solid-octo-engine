package tr.yetenekler;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.block.Block;
import org.bukkit.Material;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.inventory.meta.Damageable;

import java.util.*;

public final class YeteneklerPlugin extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, String> abilities = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Long> shadowUntil = new HashMap<>();
    private final Map<UUID, Long> spiritUntil = new HashMap<>();
    private final Set<UUID> hiddenByPlugin = new HashSet<>();
    private final Map<UUID, Long> lastHeal = new HashMap<>();
    private final String menuTitle = ChatColor.DARK_PURPLE + "Yetenek Seç";

    private static final String[] KEYS = {
        "golge", "alev", "simsek", "dev", "denizci",
        "ziplayan", "buz", "madenci", "ruh", "sifaci"
    };

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String key : KEYS) {
            if (!getConfig().contains("abilities." + key)) {
                getConfig().set("abilities." + key, "");
            }
        }
        saveConfig();
        loadAbilities();
        Objects.requireNonNull(getCommand("yetenek")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("Yetenekler etkinleştirildi.");
    }

    private void loadAbilities() {
        for (String uuid : getConfig().getConfigurationSection("players") == null
                ? Collections.<String>emptyList()
                : getConfig().getConfigurationSection("players").getKeys(false)) {
            String value = getConfig().getString("players." + uuid, "");
            if (value != null && Arrays.asList(KEYS).contains(value)) {
                abilities.put(UUID.fromString(uuid), value);
            }
        }
    }

    private void saveAbility(Player player, String ability) {
        abilities.put(player.getUniqueId(), ability);
        getConfig().set("players." + player.getUniqueId(), ability);
        saveConfig();
        player.sendMessage(ChatColor.GREEN + "Yetenegin secildi: " + pretty(ability));
    }

    private String pretty(String key) {
        return switch (key) {
            case "golge" -> "Gölge";
            case "alev" -> "Alev";
            case "simsek" -> "Şimşek";
            case "dev" -> "Dev";
            case "denizci" -> "Denizci";
            case "ziplayan" -> "Zıplayan";
            case "buz" -> "Buz";
            case "madenci" -> "Madenci";
            case "ruh" -> "Ruh";
            case "sifaci" -> "Şifacı";
            default -> key;
        };
    }

    private String getAbility(Player p) { return abilities.get(p.getUniqueId()); }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Bu komut oyuncu tarafından kullanılmalı.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("sec")) {
            openMenu(p);
            return true;
        }
        if (args[0].equalsIgnoreCase("kullan")) {
            useAbility(p);
            return true;
        }
        if (args[0].equalsIgnoreCase("ver") && args.length >= 3 && sender.hasPermission("yetenekler.admin")) {
            Player target = Bukkit.getPlayerExact(args[1]);
            String key = args[2].toLowerCase(Locale.ROOT);
            if (target == null || !Arrays.asList(KEYS).contains(key)) {
                p.sendMessage(ChatColor.RED + "Kullanım: /yetenek ver <oyuncu> <golge|alev|simsek|dev|denizci|ziplayan|buz|madenci|ruh|sifaci>");
                return true;
            }
            saveAbility(target, key);
            p.sendMessage(ChatColor.GREEN + target.getName() + " oyuncusuna " + pretty(key) + " verildi.");
            return true;
        }
        p.sendMessage(ChatColor.YELLOW + "Komutlar: /yetenek, /yetenek kullan");
        return true;
    }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, menuTitle);
        Material[] icons = {Material.ENDER_EYE, Material.BLAZE_POWDER, Material.LIGHTNING_ROD,
            Material.IRON_BLOCK, Material.HEART_OF_THE_SEA, Material.RABBIT_FOOT,
            Material.PACKED_ICE, Material.IRON_PICKAXE, Material.SOUL_LANTERN, Material.GOLDEN_APPLE};
        String[] descriptions = {
            "Eğil + sağ tık: 15 sn görünmezlik (45 sn bekleme)",
            "Ateş ve lav hasarından etkilenmez",
            "/yetenek kullan: baktığın yere kısa mesafe ışınlan",
            "Ekstra 6 kalp, daha yavaş hareket",
            "Suda hızlı yüzme ve su altında nefes",
            "Yüksek zıplama ve düşme hasarı yok",
            "Vurduğun oyuncuya yavaşlık verir",
            "Madenler eritilmiş ürün olarak düşer; Köyün Kahramanı",
            "Canın azalınca kısa süre hız ve yenilenme",
            "/yetenek kullan: kendini ve yakın arkadaşları iyileştir"
        };
        for (int i = 0; i < KEYS.length; i++) {
            ItemStack item = new ItemStack(icons[i]);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.GOLD + pretty(KEYS[i]));
            meta.setLore(Arrays.asList(ChatColor.GRAY + descriptions[i],
                    ChatColor.YELLOW + "Seçmek için tıkla"));
            item.setItemMeta(meta);
            inv.setItem(i + 8, item);
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !e.getView().getTitle().equals(menuTitle)) return;
        e.setCancelled(true);
        int slot = e.getRawSlot();
        if (slot >= 8 && slot <= 17) {
            int index = slot - 8;
            if (index < KEYS.length) {
                saveAbility(p, KEYS[index]);
                p.closeInventory();
                applyPassive(p);
            }
        }
    }

    private boolean ready(Player p, String key, int seconds) {
        long now = System.currentTimeMillis();
        long until = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).getOrDefault(key, 0L);
        if (now < until) {
            p.sendMessage(ChatColor.RED + "Bekleme süresi: " + ((until - now + 999) / 1000) + " sn.");
            return false;
        }
        cooldowns.get(p.getUniqueId()).put(key, now + seconds * 1000L);
        return true;
    }

    private void useAbility(Player p) {
        String a = getAbility(p);
        if (a == null) { p.sendMessage(ChatColor.RED + "Önce /yetenek ile bir yetenek seç."); return; }
        switch (a) {
            case "simsek" -> {
                if (!ready(p, a, 20)) return;
                org.bukkit.util.RayTraceResult result = p.getWorld().rayTraceBlocks(p.getEyeLocation(),
                    p.getEyeLocation().getDirection(), 8, FluidCollisionMode.NEVER, true);
                Location dest = result != null && result.getHitPosition() != null
                    ? result.getHitPosition().toLocation(p.getWorld()).add(0, 0.2, 0)
                    : p.getLocation().add(p.getLocation().getDirection().multiply(5));
                dest.setYaw(p.getLocation().getYaw()); dest.setPitch(p.getLocation().getPitch());
                p.teleport(dest);
                p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p.getLocation(), 25, .4, .5, .4, .05);
                p.playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, .5f, 1.8f);
            }
            case "sifaci" -> {
                if (!ready(p, a, 30)) return;
                for (Entity entity : p.getNearbyEntities(5, 5, 5)) {
                    if (entity instanceof Player ally) ally.setHealth(Math.min(ally.getAttribute(Attribute.MAX_HEALTH).getValue(), ally.getHealth() + 6));
                }
                p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + 6));
                p.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, p.getLocation(), 35, 1, 1, 1, .1);
                p.sendMessage(ChatColor.GREEN + "Şifa yayıldı!");
            }
            default -> p.sendMessage(ChatColor.YELLOW + "Bu yeteneğin aktif özelliği özel koşulla veya pasif olarak çalışır.");
        }
    }

    private void applyPassive(Player p) {
        String a = getAbility(p);
        if (a == null) return;
        if (a.equals("dev")) {
            var attr = p.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) attr.setBaseValue(32.0);
            p.setHealth(Math.min(p.getHealth(), 32.0));
            var speed = p.getAttribute(Attribute.MOVEMENT_SPEED);
            if (speed != null) speed.setBaseValue(0.085);
        } else {
            var attr = p.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) attr.setBaseValue(20.0);
            var speed = p.getAttribute(Attribute.MOVEMENT_SPEED);
            if (speed != null) speed.setBaseValue(0.1);
        }
        if (a.equals("alev")) p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false, true));
        if (a.equals("denizci")) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, Integer.MAX_VALUE, 0, false, false, true));
            p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, false, false, true));
        }
        if (a.equals("ziplayan")) p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 1, false, false, true));
        if (a.equals("madenci")) p.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, Integer.MAX_VALUE, 0, false, false, true));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> applyPassive(e.getPlayer()), 20L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> applyPassive(e.getPlayer()), 10L);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!p.isSneaking() || !"golge".equals(getAbility(p))) return;
        if (!ready(p, "golge", 45)) return;
        shadowUntil.put(p.getUniqueId(), System.currentTimeMillis() + 15_000L);
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 300, 0, false, false, true));
        p.sendMessage(ChatColor.DARK_PURPLE + "Gölge: 15 saniyeliğine görünmezsin!");
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        String a = getAbility(p);
        if ("alev".equals(a) && (e.getCause() == DamageCause.FIRE || e.getCause() == DamageCause.FIRE_TICK
                || e.getCause() == DamageCause.LAVA || e.getCause() == DamageCause.HOT_FLOOR)) e.setCancelled(true);
        if ("ziplayan".equals(a) && e.getCause() == DamageCause.FALL) e.setCancelled(true);
        if ("ruh".equals(a) && p.getHealth() - e.getFinalDamage() <= 8 && spiritUntil.getOrDefault(p.getUniqueId(), 0L) < System.currentTimeMillis()) {
            spiritUntil.put(p.getUniqueId(), System.currentTimeMillis() + 15_000L);
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 1));
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 0));
        }
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity target)) return;
        if ("buz".equals(getAbility(p)) && target instanceof Player victim) {
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 0));
        }
    }

    @EventHandler
    public void onMine(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!"madenci".equals(getAbility(p))) return;
        Block block = e.getBlock();
        Material drop = switch (block.getType()) {
            case IRON_ORE, DEEPSLATE_IRON_ORE, RAW_IRON_BLOCK -> Material.IRON_INGOT;
            case GOLD_ORE, DEEPSLATE_GOLD_ORE, NETHER_GOLD_ORE, RAW_GOLD_BLOCK -> Material.GOLD_INGOT;
            case COPPER_ORE, DEEPSLATE_COPPER_ORE, RAW_COPPER_BLOCK -> Material.COPPER_INGOT;
            case ANCIENT_DEBRIS -> Material.NETHERITE_SCRAP;
            default -> null;
        };
        if (drop == null) return;
        e.setDropItems(false);
        int amount = 1;
        if (block.getType() == Material.NETHER_GOLD_ORE) amount = 2 + new Random().nextInt(4);
        block.getWorld().dropItemNaturally(block.getLocation(), new ItemStack(drop, amount));
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (e.getTo() == null) return;
        if (e.getTo().getY() == e.getFrom().getY()) return;
        if ("dev".equals(getAbility(p))) {
            // Hareket hızı applyPassive içinde düşürülür.
        }
    }
}
