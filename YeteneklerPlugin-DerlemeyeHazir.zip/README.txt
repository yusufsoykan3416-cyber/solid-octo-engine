YETENEKLER - Paper plugin kaynak projesi

İÇERİK
- 10 yetenek için ilk sürüm kaynak kodu
- /yetenek : yetenek menüsünü açar
- Menüde bir yeteneğe tıklayarak seçersin
- /yetenek kullan : aktif yetenekleri kullanır (Şimşek ve Şifacı)
- Gölge: eğil + sağ tık, 15 sn görünmezlik, 45 sn bekleme
- Buz: oyuncuya vurunca yavaşlık
- Zıplayan: düşme hasarı yok
- Madenci: demir/altın/bakır/antik kalıntı otomatik eritme ve Köyün Kahramanı efekti
- Dev: 16 kalp toplam can ve daha yavaş hareket

ÖNEMLİ
1. Bu ZIP bir KAYNAK KOD projesidir; doğrudan plugins klasörüne konulamaz.
2. Derlemek için Java 21 ve Gradle gerekir. Derleme sonunda build/libs/Yetenekler-1.0.0.jar oluşur.
3. Aternos özel .jar yüklemeyi desteklemez; kendi JAR'ını Aternos'a doğrudan yükleyemezsin.
4. Bu ilk sürümün test edilmesi ve iyileştirilmesi gerekir. Minecraft/Paper API sürümüne göre build.gradle sürümü gerekirse güncellenmelidir.

TELEFONDAN JAR DERLEME (GitHub Actions)
- Bu projede .github/workflows/build.yml dosyası vardır.
- Projeyi GitHub'da bir depoya yükleyip main/master dalına gönderdiğinde derleme otomatik çalışır.
- Depodaki Actions sekmesinden tamamlanan çalışmayı açıp Artifacts bölümündeki Yetenekler-JAR dosyasını indir.
- Derleme hatası olursa Actions günlüklerindeki hata metnini paylaş.
